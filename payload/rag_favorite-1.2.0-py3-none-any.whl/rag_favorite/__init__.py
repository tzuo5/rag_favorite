"""Public package metadata for rag-favorite."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "1.2.0"
