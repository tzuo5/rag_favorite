"""Canonical SQL migration package."""
